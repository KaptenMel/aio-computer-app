# AIO CLI App

Welcome to **AIO CLI App**, an all‑in‑one command‑line utility designed to put a suite of handy tools at your fingertips.  The app is built in Python with the [Typer](https://typer.tiangolo.com/) framework, which makes it easy to organise a large number of sub‑commands.  Tools are grouped by category so you can quickly find the right command when you need it.

**Ethics and legality:** While some tools in this project fall under *security* or *network analysis*, they are intended **solely for educational and ethical purposes**.  Please respect privacy, abide by your local laws, and use these tools only on machines and networks you own or have explicit permission to test.

## Features

The application offers forty individual commands split across five categories.  Each command has built‑in help (`--help`) describing its usage and options.  Below is an overview of what is currently implemented:

### Network tools

| Command                | Description                                                          |
|------------------------|----------------------------------------------------------------------|
| `port‑scan`            | Scan TCP ports on a host using a configurable range and timeout.     |
| `ping`                 | Send ICMP echo requests to test host reachability.                   |
| `dns‑lookup`           | Perform a DNS lookup (A/AAAA records) for a given hostname.          |
| `whois`                | Query WHOIS information for a domain.                                |
| `traceroute`           | Trace the network path to a host.                                    |
| `ip‑geo`               | Find approximate geolocation for an IP address.                      |
| `http‑headers`         | Fetch and display HTTP response headers for a URL.                   |
| `subdomains`           | Enumerate sub‑domains from a simple wordlist (basic example).        |
| `speed‑test`           | Measure download speed using a public test file.                     |
| `mac‑vendor`           | Identify the manufacturer of a network device by its MAC address.     |

### Security tools

| Command                | Description                                                          |
|------------------------|----------------------------------------------------------------------|
| `generate‑password`    | Create a random password of arbitrary length and complexity.         |
| `hash`                 | Compute a file or string hash (MD5, SHA1, SHA256).                   |
| `check‑password`       | Assess the strength of a password and suggest improvements.          |
| `base64‑encode`        | Encode data into Base64 format.                                      |
| `base64‑decode`        | Decode Base64‑encoded data.                                          |
| `caesar‑cipher`        | Encrypt or decrypt using a simple Caesar cipher.                    |
| `list‑hidden`          | List hidden files in a directory.                                    |
| `secure‑delete`        | Overwrite and remove a file permanently (shred).                    |
| `zip‑encrypt`          | Create a password‑protected ZIP archive.                             |
| `backup`               | Back up a directory to a compressed archive.                         |

### System tools

| Command                | Description                                                          |
|------------------------|----------------------------------------------------------------------|
| `disk‑usage`           | Display disk usage statistics for a path.                            |
| `processes`            | List running processes with PID and command.                         |
| `sys‑info`             | Show basic system information (OS, CPU, memory).                     |
| `find‑file`            | Search for files matching a pattern in a directory tree.             |
| `compress`             | Compress files/directories into a `.tar.gz` archive.                 |
| `grep`                 | Search for a text pattern within files.                              |
| `monitor`              | Watch CPU and memory usage live.                                     |
| `clipboard`            | Copy text to or read text from the system clipboard.                 |

### Utility tools

| Command                | Description                                                          |
|------------------------|----------------------------------------------------------------------|
| `weather`              | Fetch current weather information for a city.                        |
| `currency‑convert`     | Convert an amount from one currency to another.                      |
| `unit‑convert`         | Convert between units (length, weight, temperature).                 |
| `todo`                 | Manage a simple to‑do list stored locally.                           |
| `timer`                | Countdown timer with optional alert sound.                           |
| `stopwatch`            | Simple stopwatch to track elapsed time.                              |
| `notes`                | Append and view notes in a local file.                               |
| `random`               | Generate random numbers, strings, or select random list items.       |

### Fun tools

| Command                | Description                                                          |
|------------------------|----------------------------------------------------------------------|
| `ascii‑art`            | Convert text into a stylised ASCII art banner.                       |
| `joke`                 | Tell a random (family‑friendly) joke fetched from an API.            |
| `fortune`              | Display a random fortune or proverb.                                 |
| `quote`                | Show an inspirational quote.                                         |

## Installation

1. Ensure you have **Python 3.8+** installed.
2. Clone or download this repository.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Run the CLI using the `aio` entry point:

   ```bash
   python -m aio_cli.main --help
   ```

Each sub‑command has its own `--help` flag that explains available options and arguments.

## Contribution

Contributions are welcome!  Feel free to open issues or pull requests to add new features, fix bugs, or improve existing commands.  Please make sure your additions respect the ethical and legal guidelines of this project.
